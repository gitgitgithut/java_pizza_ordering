package application;
/**
 * @author Yumou Wei
 * @netid 12yw14
 * @version Mar 2, 2017
 */

import java.io.Serializable;
import java.text.DecimalFormat;

public class Pizza implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String size;
	private int cheese;
	private int ham;
	private int pepperoni;
	
	/**
	 * This is the first constructor for pizza 
	 * @param size an input string from customer
	 * @exception IllegalPizza
	 */
	
	public Pizza(String size) throws IllegalPizza{
		if(size == null)
			throw new IllegalPizza("IllegalPizza!");
		
		else if(size.equalsIgnoreCase("small") || size.equalsIgnoreCase("medium")
				|| size.equalsIgnoreCase("large")){				
			this.size = size.toLowerCase();
			this.cheese = 1;
			this.ham = 0;
			this.pepperoni = 1;
		}
	
		else
			throw new IllegalPizza("IllegalPizza!");
	}
	
	/**
	 * This is the second constructor for pizza. You can put the amount
	 * of toppings you want to add.	  
	 * @param size an input string from customer. 
	 * @param cheese
	 * @param ham
	 * @param pepperoni
	 * @exception IllegalPizza
	 */
	
	public Pizza(String size, int cheese, int ham, int pepperoni) throws IllegalPizza{		
		if(size == null || (cheese < 1 || cheese > 3) || ham < 0|| ham >3 || pepperoni < 0 || pepperoni >3
				|| (ham+pepperoni) > 3)
			throw new IllegalPizza("IllegalPizza!");
			
		else if(size.equalsIgnoreCase("small") || size.equalsIgnoreCase("medium")
				|| size.equalsIgnoreCase("large")){				
			this.size = size;
			this.cheese = cheese;
			this.ham = ham;
			this.pepperoni = pepperoni;
		}
		
		else{
			throw new IllegalPizza("IllegalPizza!");}		
	}
	
	/**
	 * This method is used to get the total cost of the pizza
	 * @return total cost of the pizza
	 */
	
	public double getCost(){
		double cost = 0;
		double pizza = 0;
		if(size.equalsIgnoreCase("small"))
			pizza = 7;
		else if(size.equalsIgnoreCase("medium"))
			pizza = 9;
		else
			pizza = 11;
		cost = ((cheese-1) + ham + pepperoni) * 1.5 + pizza;
		return cost;
	}
	
	public String getSize(){
		return this.size;
	}
	
	public int getCheese(){
		return this.cheese;
	}
	
	public int getHam(){
		return this.ham;
	}
	
	public int getPepperoni(){
		return this.pepperoni;
	}
	
	/**
	 * @return the output string
	 */
	
	public String toString(){
		DecimalFormat dec = new DecimalFormat("#0.00");
		String[] Scheese = {"", ", cheese", ", double cheese", ", triple cheese"};
		String[] Sham = {"", ", ham", ", double ham", ", triple ham"};
		String[] Spepperoni = {"", ", pepperoni", ", double pepperoni", ", triple pepperoni"};
		
		if(ham == 0 && pepperoni == 0)
			return size + " pizza" + Scheese[cheese] + " only" + ". Cost: $" + dec.format(getCost()) + " each.";
		else
			return size + " pizza" + Scheese[cheese] + Sham[ham] + 
				Spepperoni[pepperoni] + ". Cost: $" + dec.format(getCost()) + " each.";
	}
	
	@Override
	public Pizza clone()
	{	
		try {
		     return (Pizza)super.clone();
		}catch (CloneNotSupportedException e) {
		    // System.out.println("Cloning not allowed.");
		     return this;
		}		  
	}

	/**
	 * This method is overrided to compare two pizza objects' attributes.
	 * @param obj The one is compared with
	 * @return true if all the attributes are the same
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if(getClass() != obj.getClass())
			return false;
		Pizza other = (Pizza)obj;
		if(!this.size.equalsIgnoreCase(other.size) || this.cheese != other.cheese || this.ham != other.ham || this.pepperoni != other.pepperoni)
			return false;
		obj = this;
		return true;
	}
	
	@Override
	public int hashCode() {
	    int hash = 17;
	    hash = 31 * hash + size.hashCode();
	    hash = 31 * hash + cheese;
	    hash = 31 * hash + ham;
	    hash = 31 * hash + pepperoni;	    
	    return hash;
	}

}
