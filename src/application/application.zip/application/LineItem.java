package application;


import java.io.Serializable;
import java.util.ArrayList;

public class LineItem implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Pizza pizza;
	private int number;
	private ArrayList<Pizza> line = new ArrayList<Pizza>();
	
	/**
	 * This is the first constructor of LineItem
	 * @param pizza The input pizza object
	 * @exception IllegalPizza
	 */
	
	public LineItem(Pizza pizza) throws IllegalPizza{
		if(pizza == null)
			throw new IllegalPizza("null list!");
		this.pizza = pizza;
		line.add(pizza);
		number = line.size();		
	}
	
	/**
	 * This is the second constructor of LineItem
	 * @param number The number of pizza customer wants to order
	 * @param pizza The imput Pizza object
	 * @exception IllegalPizza
	 */
	
	public LineItem(int number, Pizza pizza) throws IllegalPizza{
		if(number > 100 || number < 1)
			throw new IllegalPizza("Out of bound!");
		if(pizza == null)
			throw new IllegalPizza("null list!");
		this.pizza = pizza;
		line.add(pizza);
		this.number = number;
	}
	
	public void setNumber(int number) throws IllegalPizza{
		if(number > 100 || number < 1)
			throw new IllegalPizza("Illeagal List!");
		this.number = number;
	}
	
	public int getNumber(){
		return number;
	}
	
	public Pizza getPizza(){
		return pizza;
	}
	
	public double getCost(){
		
		return this.pizza.getCost() * number;
	}
	
	public String toString(){
		if(number == 1)
			return " " + number + " " + this.pizza.toString();
		else
			return number + " " + this.pizza.toString() + "\nTotal cost is: " + this.getCost();
	}
	
	/**
	 *This method compare two pizzas' costs
	 *@param line The input line object 
	 *@return 0 if the cost difference less than 1,
	 *return cost difference if larger than 1.
	 */
	
	 public double compareTo(LineItem line) {
         double i = 0;
         i = line.getCost() - this.getCost();  
         if(i < 1 && i > -1)
             return 0;
         else 
        	 return Math.round(i);        
    }

}
