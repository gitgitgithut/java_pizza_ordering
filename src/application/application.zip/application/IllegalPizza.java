package application;

public class IllegalPizza extends Exception{

	private static final long serialVersionUID = 1L;

	public IllegalPizza(String message){
		super(message);
	}

}
